import 'package:firebase_auth/firebase_auth.dart';
class StaticInfo{
  static FirebaseUser currentUser;
  static bool isImageCache = false;
}